% 05-serie-e.m - Ejercicio 5 de la Guía 1: el número e como serie.
%
% Problema: calcular e como suma de la serie
%   e = 1 + 1/1! + 1/2! + 1/3! + ... + 1/N!
% con N entero positivo, y observar cómo mejora la precisión al crecer N.
%
% Es el desarrollo de Taylor de e^x en el origen evaluado en x = 1. O(N): un
% acumulado por iteración.
%
% A partir de N = 171, factorial(N) desborda a Inf y el término 1/Inf vale 0:
% esos términos ya están por debajo de la precisión de un double.

clc;

fprintf('\n========================================================\n');
fprintf('  EJERCICIO 5 - EL NÚMERO e COMO SERIE DE TAYLOR\n');
fprintf('========================================================\n');
fprintf('Serie:  e = 1 + 1/1! + 1/2! + ... + 1/N!\n');

% ----------------------------------------------------------------------
% a) Cálculo de la serie con el N pedido por el usuario
% ----------------------------------------------------------------------
N = 0;
entrada_valida = false;
intentos_maximos = 5;    % tope para no quedar repreguntando si se agota la entrada
for intento = 1:intentos_maximos
  texto = input(sprintf('\nIngrese la cantidad de sumandos a utilizar: '), 's');
  N = str2double(texto);
  if (isscalar(N) && isfinite(N) && N == fix(N) && N >= 1)
    entrada_valida = true;
    break;
  endif
  fprintf('N debe ser un entero positivo.\n');
endfor

if (!entrada_valida)
  fprintf('Se agotaron los %d intentos sin recibir un valor válido.\n', intentos_maximos);
  return;
endif

fprintf('\n--- a) Serie evaluada en N = %d ---\n', N);

tic;
total = 1;          % el primer término de la serie es 1/0! = 1
for i = 1:N
  total = total + 1 / factorial(i);
endfor
tiempo = toc;

exacto = exp(1);

fprintf('Resultado de la serie = %s\n', sprintf('%.16f', total));
fprintf('Valor exacto exp(1)   = %s\n', sprintf('%.16f', exacto));
fprintf('Error absoluto        = %.6e\n', abs(exacto - total));
fprintf('Error relativo        = %.6e\n', abs(exacto - total) / exacto);
fprintf('Tiempo de ejecución: %.6f s\n', tiempo);

% ----------------------------------------------------------------------
% b) Barrido de distintas cantidades de sumandos
% ----------------------------------------------------------------------
fprintf('\n--- b) Comportamiento según la cantidad de sumandos ---\n');
fprintf('%-10s %-22s %-14s %s\n', 'N', 'e por la serie', 'Error abs.', 'Error rel.');

valores_N = [1, 2, 5, 10, 15, 20, 25, 30, 40, 50, 100, 171, 200];
for N_actual = valores_N
  total = 1;
  for i = 1:N_actual
    total = total + 1 / factorial(i);
  endfor
  fprintf('%-10d %-22.15f %-14.6e %.6e\n', N_actual, total, ...
          abs(exacto - total), abs(exacto - total) / exacto);
endfor

% ----------------------------------------------------------------------
% Resumen
% ----------------------------------------------------------------------
fprintf('\n--- Resumen ---\n');
fprintf('La serie de e converge rapidísimo (orden factorial), alcanzando la\n');
fprintf('precisión double en ~20 términos, superando ampliamente a series lentas como Leibniz.\n');